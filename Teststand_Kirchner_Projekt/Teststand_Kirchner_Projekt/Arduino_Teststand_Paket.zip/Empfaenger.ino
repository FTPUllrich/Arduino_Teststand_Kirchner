/*
 * EMPFÄNGER-ARDUINO (ATmega328P)
 * Funktion: UART-Empfang, Bus-Timeout (>2s), Hold-Taster (D4), Alarm bei >70% Sprung, LCD 20x4 via I2C
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// I2C-Display (Adresse 0x27 oder 0x3F, 20 Zeichen, 4 Zeilen)
LiquidCrystal_I2C lcd(0x27, 20, 4);

const uint8_t BUTTON_PIN = 4;
const unsigned long TIMEOUT_MS = 2000;
const unsigned long DEBOUNCE_MS = 50;

uint16_t currentLiveVal = 0;
uint16_t displayedVal = 0;
uint16_t previousVal = 0;
bool hasValidData = false;
unsigned long lastDataTime = 0;

int lastButtonState = HIGH;
unsigned long lastDebounceTime = 0;

void setup() {
  Serial.begin(9600); // UART-Bus vom Sender
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("SYSTEM INIT...");
  delay(1000);
  lcd.clear();
}

void format10BitBin(uint16_t val, char* outBuf) {
  // 10-Bit: Format "00 1111 1111"
  outBuf[0] = (val & (1 << 9)) ? '1' : '0';
  outBuf[1] = (val & (1 << 8)) ? '1' : '0';
  outBuf[2] = ' ';
  outBuf[3] = (val & (1 << 7)) ? '1' : '0';
  outBuf[4] = (val & (1 << 6)) ? '1' : '0';
  outBuf[5] = (val & (1 << 5)) ? '1' : '0';
  outBuf[6] = (val & (1 << 4)) ? '1' : '0';
  outBuf[7] = ' ';
  outBuf[8] = (val & (1 << 3)) ? '1' : '0';
  outBuf[9] = (val & (1 << 2)) ? '1' : '0';
  outBuf[10] = (val & (1 << 1)) ? '1' : '0';
  outBuf[11] = (val & (1 << 0)) ? '1' : '0';
  outBuf[12] = '\0';
}

void updateDisplay(bool timeout, bool alarm, float devPercent) {
  char binStr[16];
  format10BitBin(displayedVal, binStr);

  // Zeile 1: BIN
  lcd.setCursor(0, 0);
  lcd.print("BIN: ");
  lcd.print(binStr);

  // Zeile 2: DEC
  lcd.setCursor(0, 1);
  lcd.print("DEC: ");
  lcd.print(displayedVal);
  lcd.print(" (Avg:10)   ");

  // Zeile 3: DEV / ALARM
  lcd.setCursor(0, 2);
  if (timeout) {
    lcd.print("ERR: COMM TIMEOUT!  ");
  } else if (alarm) {
    lcd.print("DEV: ");
    lcd.print(devPercent, 1);
    lcd.print("% [ALARM!]");
  } else {
    lcd.print("DEV: ");
    lcd.print(devPercent, 1);
    lcd.print("% [OK]    ");
  }

  // Zeile 4: MODUS
  lcd.setCursor(0, 3);
  lcd.print("MOD: HOLD [TASTE]   ");
}

void loop() {
  // 1. Serieller Datenempfang
  while (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.startsWith("VAL:")) {
      currentLiveVal = line.substring(4).toInt();
      lastDataTime = millis();
      hasValidData = true;
    }
  }

  // 2. Timeout-Erkennung
  bool isTimeout = (hasValidData && (millis() - lastDataTime > TIMEOUT_MS));

  // 3. Taster-Entprellung & Hold-Aktualisierung
  int reading = digitalRead(BUTTON_PIN);
  if (reading != lastButtonState) {
    lastDebounceTime = millis();
  }
  if ((millis() - lastDebounceTime) > DEBOUNCE_MS) {
    // Tastendruck erkannt (Falling Edge)
    if (reading == LOW && lastButtonState == HIGH) {
      previousVal = displayedVal;
      displayedVal = currentLiveVal;

      // 70%-Sprungberechnung
      float diff = abs((float)displayedVal - (float)previousVal);
      float base = (previousVal > 0) ? (float)previousVal : 1.0;
      float devPercent = (diff / base) * 100.0;
      bool isAlarm = (previousVal > 0 && devPercent >= 70.0);

      updateDisplay(isTimeout, isAlarm, devPercent);
    }
  }
  lastButtonState = reading;
}
