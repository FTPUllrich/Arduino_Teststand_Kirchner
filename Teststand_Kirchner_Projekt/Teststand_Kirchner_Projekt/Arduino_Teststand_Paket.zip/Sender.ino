/*
 * SENDER-ARDUINO (ATmega328P)
 * Funktion: Analogerfasssung (A0), Gleitender Mittelwert (N=10), UART-Sendeschleife (>=10Hz)
 */

const uint8_t ANALOG_PIN = A0;
const uint8_t WINDOW_SIZE = 10;
const unsigned long SAMPLE_INTERVAL_MS = 50;  // 20 Hz Abtastung
const unsigned long TX_INTERVAL_MS = 100;     // 10 Hz Bus-Übertragungsrate

uint16_t readings[WINDOW_SIZE];
uint8_t readIndex = 0;
uint32_t total = 0;
uint16_t average = 0;

unsigned long lastSampleTime = 0;
unsigned long lastTxTime = 0;

void setup() {
  Serial.begin(9600); // UART-Busverbindung zum Empfänger
  for (uint8_t i = 0; i < WINDOW_SIZE; i++) {
    readings[i] = analogRead(ANALOG_PIN);
    total += readings[i];
  }
  average = total / WINDOW_SIZE;
}

void loop() {
  unsigned long currentMillis = millis();

  // 1. Abtastung & Gleitender Mittelwert
  if (currentMillis - lastSampleTime >= SAMPLE_INTERVAL_MS) {
    lastSampleTime = currentMillis;
    total -= readings[readIndex];
    readings[readIndex] = analogRead(ANALOG_PIN);
    total += readings[readIndex];
    readIndex = (readIndex + 1) % WINDOW_SIZE;
    average = total / WINDOW_SIZE;
  }

  // 2. Zyklische Übertragung via UART (Format: VAL:<wert>\n)
  if (currentMillis - lastTxTime >= TX_INTERVAL_MS) {
    lastTxTime = currentMillis;
    Serial.print("VAL:");
    Serial.println(average);
  }
}
