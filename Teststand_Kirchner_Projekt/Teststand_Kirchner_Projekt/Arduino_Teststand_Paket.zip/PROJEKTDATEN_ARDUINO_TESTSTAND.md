# 📋 Projekt: Mikrocontroller-Teststand (2× Arduino Uno R3 & LCD-Display)

Dieses Dokument fasst alle Anforderungen, Schnittstellen, Pinbelegungen und offenen Punkte aus dem **System-Anforderungsprotokoll / Lastenheft (VDI 2206 / VDI 2221)** zusammen. Es kann direkt in Antigravity auf jedem System als Kontext genutzt werden.

---

## 1. Systemarchitektur & Übersicht

Das Gesamtsystem besteht aus zwei gekoppelten Arduino Uno R3 (ATmega328P):

```
┌───────────────────────────────────────────────────────────┐
│ SENDER-ARDUINO                                            │
│ • Analogeingang A0 (0..5V, 10-Bit ADC, 0..1023)           │
│ • Gleitender arithmetischer Mittelwert (N = 10 Samples)   │
│ • Zyklische Übertragung (>= 10 Hz) via UART-Bus           │
└─────────────────────────────┬─────────────────────────────┘
                              │ TX (Pin 1 oder D2)
                              │ UART 5V TTL
                              │ Zwingend gemeinsame Bezugsmasse (GND)
                              ▼ RX (Pin 0 oder D3)
┌───────────────────────────────────────────────────────────┐
│ EMPFÄNGER-ARDUINO                                         │
│ • Empfang & Timeout-Überwachung (> 2 s -> Fehlermeldung)  │
│ • Grenzwertüberwachung (|Δ| >= 70% -> optischer Alarm)    │
│ • Hold-Funktion über Taster an Pin D4 (entprellt >= 50ms) │
│ • I2C-Ansteuerung (A4=SDA, A5=SCL, 100 kHz)              │
└─────────────────────────────┬─────────────────────────────┘
                              │ I2C (PCF8574 Backpack, Adr. 0x27/0x3F)
                              ▼
┌───────────────────────────────────────────────────────────┐
│ DISPLAY (HD44780 LCD 20×4)                                │
│ Zeile 1: BIN: 00 1111 1111  (10-Bit mit 4er-Nibbles)      │
│ Zeile 2: DEC: 1023 (Avg:10) (Dezimalwert + Filterinfo)    │
│ Zeile 3: DEV: +00.0% [OK]   (Abweichungs- & Alarmstatus)  │
│ Zeile 4: MOD: HOLD [TASTE]  (Betriebsmodus)               │
└───────────────────────────────────────────────────────────┘
```

---

## 2. Pinbelegung & Anschlüsse

### Sender-Arduino
| Baugruppe / Signal | Arduino Pin | Schnittstelle / Pegel | Funktion / Bemerkung |
| :--- | :--- | :--- | :--- |
| **Analogsensor (Poti/DMS)** | Pin A0 | 0 .. 5 V DC | Analog IN (0..1023 Digits), erweiterbar A1..A5 |
| **UART TX** | Pin 1 (TX) oder D2 (SoftSerial) | 5V TTL | Zyklische Datenübertragung zum Empfänger |
| **Spannungsversorgung** | 5V / GND | +5 V DC | Gemeinsames Bezugspotenzial (GND) zwingend |

### Empfänger-Arduino
| Baugruppe / Signal | Arduino Pin | Schnittstelle / Pegel | Funktion / Bemerkung |
| :--- | :--- | :--- | :--- |
| **UART RX** | Pin 0 (RX) oder D3 (SoftSerial) | 5V TTL | Empfängt Messwerte vom Sender |
| **I2C SDA** | Pin A4 | 5V I2C (Pull-Up) | LCD PCF8574 Datenleitung (Adr. 0x27 / 0x3F) |
| **I2C SCL** | Pin A5 | 5V I2C (Pull-Up) | LCD PCF8574 Taktleitung (100 kHz) |
| **Aktualisierungs-Taster** | Pin D4 (oder D2 mit INT) | Active-LOW (INPUT_PULLUP) | Hold-/Trigger-Taster zum Aktualisieren |
| **Spannungsversorgung** | 5V / GND | +5 V DC | Gemeinsames Bezugspotenzial mit Sender |

---

## 3. Anforderungskatalog (VDI 2206 / 2221)

| ID | Kategorie | Spezifikation | Art | Zielwert / Kriterium | Verifikation | Prio |
| :--- | :--- | :--- | :---: | :--- | :--- | :---: |
| **A-01** | Sensorik | Analoge Eingangserfassung | F | 10-Bit-ADC (0..1023 Digits, 0..5V) an Pin A0 | Multimeter / Signalgenerator | Hoch |
| **A-02** | Signalverarbeitung | Filterung / Mittelwert | F | Gleitender Mittelwert N = 10 Samples, Δt parametrierbar | Signalvergleich im Serial Plotter | Hoch |
| **A-03** | Skalierung | Multi-Kanal-Erweiterung | W | Architektur ausgelegt für bis zu 6 Kanäle (A0–A5) | Funktionstest mit Analoggebern | Mittel |
| **A-04** | Kommunikation | Zyklische Busübertragung | F | Zyklische Übertragung via UART, Rate f_bus >= 10 Hz | Logikanalysator / Trace | Hoch |
| **A-05** | Robustheit | Bus-Timeout-Überwachung | F | Erkennung von Verbindungsabbruch (> 2 s) -> Alarm | RX/TX-Trennung im Testbetrieb | Hoch |
| **A-06** | HMI / Display | LCD-Ansteuerung | F | HD44780-kompatibel via I2C (PCF8574 Backpack) | I2C-Scan / Funktionstest | Hoch |
| **A-07** | HMI / Format | Binäre Messwertdarstellung | F | 10-Bit Binärwert mit führenden Nullen & Nibble-Trennung | Sichtprüfung | Mittel |
| **A-08** | HMI / Bedienung | Hold-Trigger / Taster | F | Anzeigeaktualisierung nur bei Tastendruck (t_deb >= 50 ms) | Tastentest | Hoch |
| **A-09** | Dynamik | HMI-Reaktionszeit | F | Latenz Taster -> Display t_lat <= 100 ms | Oszilloskop Flanke -> I2C | Mittel |
| **A-10** | Systemstart | Init-Verhalten | F | Boot-Meldung, Puffer füllen, definierter Wartezustand | Kaltstartprüfung | Mittel |
| **A-11** | Logik & Alarm | Grenzwertüberwachung | F | Optischer Alarm bei \|Wert(k) - Wert(k-1)\| >= 70% * Wert(k-1) | Sprungantwort am Geber | Hoch |
| **A-12** | Logik & Alarm | Alarm-Rücksetzung | F | Alarm aktiv, bis Wert im Toleranzbereich oder quittiert | Stufentest mit Signalrückkehr | Hoch |
| **A-13** | Datenspeicher | Status-Vorhaltung | F | Vorhaltung von aktuellem Wert, Vorgänger & Status im SRAM | Code-Review / Debug-Trace | Hoch |
| **A-14** | Elektrik | Potenzialausgleich | F | +5V DC Versorgung, zwingend gemeinsamer GND | DMM-Messung | Hoch |
| **A-15** | Umwelt | Betriebsumgebung | F | 10 °C bis 40 °C, Laborumgebung, Kurzschlussschutz | Sichtprüfung | Niedrig |

*Legende: F = Festforderung (Muss), W = Wunschforderung (Soll/Kann)*

---

## 4. Offene Punkte & Diskussionsgrundlage (Katalog)

* **OP-01 (Sensorik):** Konkreter Geber festlegen (z. B. 10k Potentiometer, LM35 Temperaturfühler oder DMS-Kraftaufnehmer).
* **OP-02 (Mathematik / Alarm):** Division durch 0 bei 70%-Sprung abfangen (`max(Wert_alt, 1)` oder Mindestabweichung z. B. 50 Digits).
* **OP-03 (Filter-Abtastung):** Fester Timer-Interrupt vs. nicht-blockierende `millis()` im Hauptloop.
* **OP-04 (UART-Protokoll):** Framing festlegen (z. B. ASCII `VAL:0512\n` oder Binärframe mit Startbyte + Checksumme).
* **OP-05 (Kanalumschaltung):** Bei Multi-Sensorik: Durchlauf per Timer oder Umschalten per langem Tastendruck.
* **OP-06 (Displayformat):** Bevorzugt LCD 20×4 I2C wegen Nibble-Gruppierung und Statustexten.
* **OP-07 (Mechanik):** Labor-Breadboard vs. Montageplatte (Acrylglas / Item-Aluprofil / 3D-Druck).
* **OP-08 (Fehlerbehandlung):** Displayanzeige bei Timeout (`COMM TIMEOUT` + blinkende Warnung).
